from django.db import models

# Create your models here.
class Blog(models.Model):
    titleOfBlog=models.CharField(max_length=20)
    techName=models.CharField(max_length=20)
    textBlog=models.TextField(max_length=200)
    numberOfBlogs=models.CharField(max_length=200)
    autherName=models.CharField(max_length=200)

class signUp(models.Model):
    Name=models.CharField(max_length=20)
    EmailId=models.CharField(max_length=20)
    UserName=models.CharField(max_length=20)
    Password=models.CharField(max_length=20)

class login(models.Model):
    username=models.CharField(max_length=10)
    password=models.CharField(max_length=10)
