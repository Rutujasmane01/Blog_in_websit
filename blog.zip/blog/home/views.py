from django.shortcuts import render
from home.models import Blog
from home.models import signUp
from home.models import login
# Create your views here.
def home(request):
    if(request.method=='GET'):
        allBlogs=Blog.objects.all()
        print(allBlogs)
        allBlogs=allBlogs[1:]
        return render(request,'home.html',{'allBlogs':allBlogs})

    
def blogForm(request):
    if(request.method=='GET'):
         return render(request,'blogForm.html',{'msg':''})
    if(request.method=='POST'):
        try:
            title=request.POST.get("title")
            tname=request.POST.get("tname")
            text=request.POST.get("written")
            autherName=request.POST.get("auther")
            bg=Blog()
            bg.titleOfBlog=title
            bg.techName=tname
            bg.textBlog=text
            bg.numberOfBlogs=0
            bg.autherName=autherName
            bg.save()
            return render(request,'blogForm.html',{'msg':'Blog Posted Successfully !'})
        except:
            return render(request,'blogForm.html',{'msg':'Failed to Post Blog !'})



def signUpForm(request):
    if(request.method=='GET'):
         return render(request,'signUpForm.html',{'msg':''})
    if(request.method=='POST'):
        try:
            name=request.POST.get("name1")
            emailId=request.POST.get("email")
            username=request.POST.get("username1")
            password=request.POST.get("password1")
            ag=signUp()
            ag.Name=name
            ag.EmailId=emailId
            ag.UserName=username
            ag.Password=password
            ag.save()
            return render(request,'signUpForm.html',{'msg':'Sign in Successfull !'})
        except:
            return render(request,'signUpForm.html',{'msg':'Failed to Sign in !'})

        
def loginForm(request):
    if(request.method=='GET'):
         return render(request,'loginForm.html',{'msg':''})
    if(request.method=='POST'):
        try:
            username=request.POST.get("username1")
            password=request.POST.get("password1")
            ag=login()
            ag.Password=password
            ag.save()
            return render(request,'signUpForm.html',{'msg':'Sign in Successfull !'})
        except:
            return render(request,'signUpForm.html',{'msg':'Failed to Sign in !'})

